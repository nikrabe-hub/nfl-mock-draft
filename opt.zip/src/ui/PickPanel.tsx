import { useMemo, useState } from 'preact/hooks';
import { autoPickNow, discardDraft, draftStore, userPick } from '../draft/controller';
import { availablePlayers, currentSlot, isUserTeam, needStatus, remainingPicks, teamDrafted, type DraftSession } from '../draft/engine';
import { getTeam, teamLabel } from '../data/teams';
import { buildRecap } from '../export/recap';
import { gradeDraft, gradeIndex } from '../draft/grades';
import { useT } from '../i18n';
import { useStore } from '../store';
import { PlayerList } from './PlayerList';
import { GradeBadge } from './GradeBadge';
import { RecapExport } from './RecapExport';
import { TeamLogo } from './TeamLogo';

type Tab = 'draft' | 'trade' | 'analysis';

const draftPlayer = (id: string) => {
  userPick(id);
};

function NeedChips({ session, team }: { session: DraftSession; team: string }) {
  const t = useT();
  const needs = needStatus(session, team);
  return (
    <div class="need-chips" data-testid="need-chips">
      <span class="small muted">{t('draft.needs')}:</span>
      {needs.map((n) => (
        <span key={n.pos} class={n.filled > 0 ? 'chip need done' : 'chip need'} title={n.filled > 0 ? t('panel.analysis.filled', { count: n.filled }) : t('panel.analysis.open')}>
          {n.pos}
        </span>
      ))}
    </div>
  );
}

function Analysis({ session, team }: { session: DraftSession; team: string }) {
  const t = useT();
  const drafted = teamDrafted(session, team);
  return (
    <div data-testid="analysis">
      <h3 class="sub">{t('panel.analysis.needs')}</h3>
      <ul class="plain-list">
        {needStatus(session, team).map((n) => (
          <li key={n.pos}>
            {n.pos}: {n.filled > 0 ? t('panel.analysis.filled', { count: n.filled }) : t('panel.analysis.open')}
          </li>
        ))}
      </ul>
      <p class="muted small hint">{t('draft.needs.estimated')}</p>
      <h3 class="sub">{t('panel.analysis.picks')}</h3>
      {drafted.length === 0 ? (
        <p class="muted small">{t('panel.analysis.none')}</p>
      ) : (
        <ul class="plain-list">
          {drafted.map((p) => (
            <li key={p.id}>
              {p.name} ({p.pos}, {p.college || '–'})
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function TeamResult({ session, grades, team }: { session: DraftSession; grades: ReturnType<typeof gradeDraft>; team: string }) {
  const t = useT();
  const recap = useMemo(() => buildRecap(session, grades, team), [session, grades, team]);
  if (!recap) return null;
  return (
    <div class="mine-block" data-testid={`result-${team}`}>
      <div class="result-head">
        <TeamLogo abbr={team} size={44} />
        <div class="result-title">
          <strong>{teamLabel(team)}</strong>
          <span class="small muted">
            {t('grade.needs60')}: {recap.needScore} · {t('grade.value40')}: {recap.valueScore}
          </span>
        </div>
        <div class="result-grade">
          <GradeBadge grade={recap.grade} size="lg" testid={`grade-team-${team}`} />
          <span class="small muted">{t('grade.team')}</span>
        </div>
      </div>
      <ul class="result-picks">
        {recap.rows.map((r) => (
          <li key={r.pick} data-testid="result-pick">
            <span class="rp-no">{r.pick}</span>
            <span class="rp-main">
              <strong>{r.name}</strong>
              <span class="small muted">
                {r.pos} · {r.college}
                {r.rank != null ? ` · Rank ${r.rank}` : ''}
                {r.needPos ? ` · Need ${r.needPos}` : ''}
              </span>
            </span>
            <GradeBadge grade={r.grade} size="md" testid="result-grade" />
          </li>
        ))}
      </ul>
      <p class="small muted">
        {t('grade.covered')}: {recap.covered.length ? recap.covered.join(', ') : '–'} · {t('grade.open')}: {recap.open.length ? recap.open.join(', ') : '–'}
      </p>
      <RecapExport recap={recap} />
    </div>
  );
}

function AllTeams({ grades }: { grades: ReturnType<typeof gradeDraft> }) {
  const t = useT();
  const list = Object.values(grades.teams).sort((a, b) => gradeIndex(a.grade) - gradeIndex(b.grade) || b.score - a.score);
  return (
    <details class="all-grades" data-testid="all-grades">
      <summary>{t('grade.allTeams')}</summary>
      <ol class="plain-list">
        {list.map((tg) => (
          <li key={tg.team} class="all-row" data-testid="all-grade-row">
            <TeamLogo abbr={tg.team} size={28} />
            <span>{teamLabel(tg.team)}</span>
            <GradeBadge grade={tg.grade} size="sm" />
          </li>
        ))}
      </ol>
    </details>
  );
}

function Finished({ session, onNew }: { session: DraftSession; onNew: () => void }) {
  const t = useT();
  const mine = session.config.userTeams;
  const grades = useMemo(() => gradeDraft(session), [session]);
  const hasPicks = mine.some((team) => teamDrafted(session, team).length > 0);
  return (
    <div class="card panel" data-testid="finished-panel">
      <h2>{t('finished.title')}</h2>
      <p>{session.endReason === 'pool_empty' ? t('finished.poolEmpty', { count: session.results.length }) : t('finished.complete', { count: session.results.length })}</p>
      <h3 class="sub">{t('finished.mine')}</h3>
      {!hasPicks ? <p class="muted small">{t('finished.none')}</p> : mine.map((team) => <TeamResult key={team} session={session} grades={grades} team={team} />)}
      <p class="small muted hint" data-testid="grade-explain">
        {t('grade.explain')}
      </p>
      <AllTeams grades={grades} />
      <div class="row">
        <button type="button" class="btn" data-testid="finished-new" onClick={onNew}>
          {t('finished.new')}
        </button>
      </div>
    </div>
  );
}

export function PickPanel({ session, onLeave }: { session: DraftSession; onLeave: () => void }) {
  const t = useT();
  const ui = useStore(draftStore);
  const [tab, setTab] = useState<Tab>('draft');
  const slot = currentSlot(session);

  if (session.status === 'finished' || !slot) {
    return (
      <Finished
        session={session}
        onNew={() => {
          discardDraft();
          onLeave();
        }}
      />
    );
  }

  const team = getTeam(slot.team);
  const mine = isUserTeam(session, slot.team);

  if (!mine) {
    return (
      <div class="card panel waiting" data-testid="waiting-panel" aria-live="polite">
        <div class="clock-head">
          <TeamLogo abbr={slot.team} size={48} />
          <div>
            <strong>{t('panel.waiting', { team: team ? team.name : slot.team, pick: slot.pick })}</strong>
            <div class="small muted">{t('draft.pickLabel', { round: slot.round, pick: slot.pick })}</div>
          </div>
        </div>
        <NeedChips session={session} team={slot.team} />
        {!ui.cpuRunning && <p class="muted small">…</p>}
      </div>
    );
  }

  return (
    <div class="card panel" data-testid="clock-panel">
      <div class="clock-banner">{t('panel.clock')}</div>
      <div class="clock-head">
        <TeamLogo abbr={slot.team} size={52} />
        <div>
          <strong class="clock-team">{team ? `${team.city} ${team.name}` : slot.team}</strong>
          <div class="small muted" data-testid="clock-pick">
            {t('draft.pickLabel', { round: slot.round, pick: slot.pick })}
            {slot.from ? ` · ↔ ${slot.from}` : ''}
          </div>
          <div class="small muted">{t('panel.remaining', { count: remainingPicks(session, slot.team) })}</div>
        </div>
      </div>
      <NeedChips session={session} team={slot.team} />

      <div class="segmented tabs" role="group" aria-label={t('panel.tabs')}>
        {(['draft', 'trade', 'analysis'] as const).map((x) => (
          <button key={x} type="button" class={tab === x ? 'seg active' : 'seg'} aria-pressed={tab === x} data-testid={`panel-tab-${x}`} onClick={() => setTab(x)}>
            {t(`panel.tab.${x}`)}
          </button>
        ))}
      </div>

      {tab === 'draft' && (
        <PlayerList
          players={availablePlayers(session)}
          canDraft
          onDraft={draftPlayer}
          extra={
            <button type="button" class="btn btn-secondary btn-compact" data-testid="auto-pick" onClick={() => autoPickNow()}>
              {t('panel.auto')}
            </button>
          }
        />
      )}
      {tab === 'trade' && <p class="notice">{t('panel.trade.soon')}</p>}
      {tab === 'analysis' && <Analysis session={session} team={slot.team} />}
    </div>
  );
}
